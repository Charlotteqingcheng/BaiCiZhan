// pages/my/my.js
// const db = wx.cloud.database({
//   env:"enirile-1"
// });
// const user_col = db.collection("user");
var app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    imgUrl:null,
    name:"",
    sex:["男","女"],
    index:0,
    date:"2020-06-09",
    hiddenmodalput: true
  },
  setPhotoInfo(){
    var that = this;
    wx.chooseImage({
      complete: (res) => {
        var tempFilePaths = res.tempFilePaths
        that.setData({
          imgUrl:tempFilePaths
        })
      },
    })
  },
  //更改名字
  changeName(e){
      //属性值
      let attr = e.target.dataset.set;
      let oldName = this.data.name;
      console.log("o",oldName)
      //值
      let value = e.detail.value;
      console.log(value)
      this.setData({
        [attr]:value
      })
      user_col.where({
        username:oldName
      }).update({
        data:{
            username:value
        },
       success:function(res){
         console.log(res)
       }
      })
  },
  //更改性别
  bindSexChange(e){
    this.setData({
      index:e.detail.value,
    })
    let name = this.data.name
    // console.log(name)
    // console.log(this.data.index)
    user_col.where({
      username:name
    }).update({
      data:{
        sex:this.data.sex[this.data.index]
      },
      success:function(res){
        console.log(res)
      }
    })
      
  },
//更改生日
bindDateChange: function(e) {
  console.log('picker发送选择改变，携带值为', e.detail.value)
  this.setData({
    date: e.detail.value
  })
  let name = this.data.name
  user_col.where({
    username:name
  }).update({
    data:{
      birthday:this.data.date
    },
    success:function(res){
      console.log(res)
    }
  })
},

modalinput(){
    this.setData({
      hiddenmodalput:!this.data.hiddenmodalput
    })
},

  //取消按钮
  cancel: function(){
    this.setData({
     hiddenmodalput: true
    });
   },
   //确认
   confirm: function(){
    this.setData({
        hiddenmodalput: true
       })
   },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      name:app.globalData.name
    })
    let num =0
    user_col.get({
      success:res=>{
        if(res.data[0].sex=='女'){
          num=1
        }
        console.log(num)
        this.setData({
            name:res.data[0].username,
            date:res.data[0].birthday,
            index:num
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})