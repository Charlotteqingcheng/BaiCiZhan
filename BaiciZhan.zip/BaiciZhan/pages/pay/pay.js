// pages/pay/pay.js
const app=getApp()
let {shop_list}=app.globalData

Page({

  /**
   * 页面的初始数据
   */
  data: {
    shop_car_list:[],
    sum:0,
    discount:0,
    postage:0
  },
  get(){
    this.setData({
      shop_car_list:shop_list.filter(item=>item.count>0)||[]
    })
  },
  sum(){
    let sum=0
    let postage=0
    let discount=0
    let {shop_car_list}=this.data
    for(var item of shop_car_list){
      sum+=item.count*item.price
      discount+=item.count*item.price*item.discount
    }
    //console.log(discount)
    if(sum<50&&sum>0){
      postage=50;
    }else if(sum>=50||sum==0){
      postage=0
    }
    discount=sum-discount
    this.setData({
      sum,
      discount,
      postage
    })
  },
  pay(){
    var _this=this
    wx.showModal({
      title:'百词斩',
      content:'确认要支付',
      success (res) {
        if (res.confirm) {
          for(var i=0;i<shop_list.length;i++){
            app.del(i)
            _this.sum()
          }
        }
      }
    })
    //console.log(shop_list)
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.get()
    this.sum()
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})