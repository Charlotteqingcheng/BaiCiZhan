var app = getApp();
var word_list = app.globalData.word_list
let page=app.globalData.page
Page({

  /**
   * 页面的初始数据
   */
  data: {
    index:0,//数组角标
    learn:3,//左上数字
    word1_list:[],
    isBindExpert:true
  },
  judge(e){
    //console.log(e)
    let _this=this
    let isBindExpert
    let num=e.target.dataset.num
    let index=this.data.index
    //app.globalData.page=index
    console.log(app.globalData.page)
    //console.log(index)
    let learn_1=this.data.learn
    if(num==2){
      wx.showToast({
        title: '正确',
        icon: 'success',
        duration: 500
      })
      if(index<2){
      index+=1
      let a=this.data.word1_list[index].id
     //console.log(a)
      this.setData({
       learn:3-a
     })
    }
      else{
        isBindExpert=false
        learn_1=0
        _this.setData({
          isBindExpert:isBindExpert,
          learn:learn_1
        })
      }
    }else{
      wx.showModal({
        title: '❌',
        content: '选择错误,跳转详情页？',
        success (res) {
          if (res.confirm) {
            // 跳转详情页
            wx.navigateTo({
              url:"/pages/Details/Details?select="+index
            })
          } else if (res.cancel) {
            index=index
          }
        }
      })
    }
    app.globalData.page=index
    this.setData({
      index:index
    })
   },
   Back(){
     let index=this.data.index
     index=0
     app.globalData.page=index
     let learn = 3-index
     this.setData({
       index:index,
       learn:learn,
       isBindExpert:true
     })
   },
   zhan(){
    let index=this.data.index
    app.globalData.page=index
    let isBindExpert
    if(index<2)
    {
    index+=1
   }else{
    isBindExpert=false
   }
   this.setData({
    index:index,
    isBindExpert:isBindExpert
  })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
  
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    let index
    index=app.globalData.page
    this.setData({
      word1_list:word_list,
      index:app.globalData.page
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})