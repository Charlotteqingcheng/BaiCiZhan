const app = getApp();
const word_list = app.globalData.word_list      //调用全局变量
let page1=app.globalData.page1
Page({

  /**
   * 页面的初始数据
   */
  data: {
    index:0,
    learn:3,
    word2_list:[],
    hid:true,
    Acc_arr:[
      {
        mean1:"n.懒蛋，懒人",
        mean2:"n.坏蛋",
        mean3:"n.好人，道德高尚的人"
      },
      {
        mean1:"n.玩耍",
        mean2:"v.工作",
        mean3:"v.逛街，散步，溜达"
      },
      {
        mean1:"n.这个不对，别选了",
        mean2:"n.土块，土嘎达",
        mean3:"n.冰，冰块"
      }
    ]
  },
  check(e){
    let _this=this
    let hid
    let mean=e.target.dataset.mean
    console.log(mean)
    let index=this.data.index
    //app.globalData.page1=index
    let learn_1=this.data.learn
    let word2_list=this.data.word2_list
    if(mean==word2_list[index].means){
      wx.showToast({
        title: '选择正确',
        icon: 'success',
        duration: 500
      })
      if(index<2){
        index+=1
        let a=this.data.word2_list[index].id
        this.setData({
         learn:3-a
       })
      }
        else{
          hid=false
          learn_1=0
          _this.setData({
            learn:learn_1,
            hid:hid
          })
        }
    }else{
      wx.showModal({
        title: '❌',
        content: '选择错误，跳转详情页？',
        success (res) {
          if (res.confirm) {
            // 跳转详情页
            wx.navigateTo({
              url:"/pages/Details/Details?select="+index
            })
          } else if (res.cancel) {
            index=index
          }
        }
      })
    }
    app.globalData.page1=index
    this.setData({
      index:index
    })
  },
  Back_1(){
    let index=this.data.index
     index=0
     app.globalData.page1=index
     let learn = 3-index
     this.setData({
       index:index,
       learn:learn,
       hid:true
     })
  },
  zhan(){
    let index=this.data.index
    app.globalData.page1=index
    let hid
    if(index<2)
    {
    index+=1
   }else{
     hid=false
   }
   this.setData({
    index:index,
    hid:hid
  })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
     //let index=this.data.index
     let index=app.globalData.page1
    this.setData({
      index:index,
      word2_list:word_list
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})