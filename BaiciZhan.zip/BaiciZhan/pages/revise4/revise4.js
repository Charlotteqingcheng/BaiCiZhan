// pages/revise4/revise4.js
const innerAudioContext = wx.createInnerAudioContext();
const innerAudioContext2 = wx.createInnerAudioContext();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    showView: false,
  },
  wrong: function(){
    const db=wx.cloud.database({
      env:"firstprogram-vdeyw"
    })
    wx.cloud.callFunction({
      name: 'cloudadd',
      data: {
        name4:"propose"
      },
      complete: res => {
        console.log('callFunction test result: ', res)
      }
    })
    if(this.data.showView == false)
    {
      this.setData({
        showView: (!this.data.showView)
      })
    }
    innerAudioContext.play();
    console.log(innerAudioContext.duration);
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    innerAudioContext.src="http://img.51miz.com/preview/sound/00/25/36/51miz-S253688-396B4CC5-thumb.mp3",
    innerAudioContext2.src="http://img.51miz.com/preview/sound/00/27/02/51miz-S270268-94A03E22.mp3"
  },
  play2: function () {
    innerAudioContext2.play();
    console.log(innerAudioContext2.duration);
  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})