const app = getApp();
const word_list = app.globalData.word_list
let coll_list=app.globalData.coll_list   //调用全局变量
let page=app.globalData.page
let coll_index=app.globalData.coll_index
let count=0
Page({

  /**
   * 页面的初始数据
   */
  data: {
    src_1:"../../图片/收藏-1.jpg",
    index:0,
    select:0,
    word2_list:[],
    charge:false    // 返回主页重新浏览收藏 判断是否已经收藏
  },
  change_1(){      //收藏功能
    let index=this.data.index
    let charge=this.data.charge
    count+=1
    if(count%2==0){
    this.setData({
      src_1:"../../图片/收藏-1.jpg",
    })
    wx.showToast({
      title: '已取消收藏',
      icon: 'success',
      duration: 1000
    })
    //移出收藏数组
    coll_list.splice(coll_index-1,1)
    coll_index-=1
    app.globalData.coll_list=coll_list
  }else{
    this.setData({
      src_1:"../../图片/收藏-2.jpg",
    })
    //添加进收藏数组
    let length=coll_list.length
    console.log(length)
    for(let i=0;i<length;i++){
      if(word_list[index]==coll_list[i]){
         charge=true
      }
    }
    if(charge==false){
      wx.showToast({
        title: '已收藏',
        icon: 'success',
        duration: 1000
      })
    coll_list[coll_index]=word_list[index]
    coll_index+=1
    app.globalData.coll_list=coll_list
    }else{
      wx.showModal({
        title: '提示',
        content: '该单词已经收藏过了呦',
        success (res) {
          if (res.confirm) {
            //console.log('用户点击确定')
          } else if (res.cancel) {
            //console.log('用户点击取消')
          }
        }
      })
    }
  }
  console.log(app.globalData.coll_list)
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
     this.setData({
       select:options.select
     })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    //console.log(page)
  
    this.setData({
      word2_list:word_list,
      index:this.data.select,//app.globalData.page,
      charge:false
    })
    count=0  //再次访问详情页 count置0

    let index=this.data.index
    let charge=this.data.charge
    let src_1=this.data.src_1
    let length=coll_list.length
    console.log(length)
    for(let i=0;i<length;i++){
      if(word_list[index]==coll_list[i]){
         charge=true
      }
    }
    if(charge==false){
       src_1="../../图片/收藏-1.jpg"
    }else{
      src_1="../../图片/收藏-2.jpg"
    }
    this.setData({
      src_1:src_1
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})