// pages/plan/plan.js
const date = new Date()
//每天几个
const everyday = []
// const days = []

for (let i = 5; i <= 100; i+=5) {
  everyday.push(i)
}

// let num1 = 1200
// let q = (num1/5).toFixed(0)
// let w =(num1/100).toFixed(0)

// for (let i =w ; i <=q; i++) {
//   days.push(i)
// }
Page({

  /**
   * 页面的初始数据
   */
  data: {
    //单词个数
    num:1200,
    //每天记几个
    everyday,
    every:0,
    //完成天数
    day: 0,
    value: [1,  9999],
  },
  bindChange(e) {
    const val = e.detail.value
    this.setData({
      every: this.data.everyday[val[0]],
    })
    let q = (this.data.num/this.data.every).toFixed(0)
    this.setData({
      day:q
    })
    console.log(this.data.day)
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log(this.data.days)
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})