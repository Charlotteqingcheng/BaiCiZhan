//app.js
wx.cloud.init()
App({
  onLaunch: function () {
    wx.cloud.init({env:"passion-wjlcn"})
  },
  onShow: function (options) {
    wx.setStorageSync("shop_list",this.globalData.shop_list)
  },
  globalData: {
    shop_list:[
      {
        id:0,
        name:"康奈尔笔记本",
        title:"系出名门，学霸专属，各种科研机构都在用",
        variety:"文具",
        price:29.8,
        count:0,
        discount:0.7
      },
      {
        id:1,
        name:"象形9000",
        title:"《百词斩象形9000》英语单词词汇书 日常 中考 高考 四级 六级 托福 雅思组合套装",
        variety:"读物",
        price:148.9,
        count:0,
        discount:0.9
      },
      {
        id:2,
        name:"两用中性笔",
        title:"【百词斩出品】两用中性笔 0.5mm 带触控头 书写顺滑",
        variety:"文具",
        price:9.8,
        count:0,
        discount:1
      },
      {
        id:3,
        name:"星球单词本",
        title:"星球单词本4本装 清晰记录4800词",
        variety:"文具",
        price:17.9,
        count:0,
        discount:1
      },
      {
        id:4,
        name:"薄荷生活洗衣凝珠",
        title:"薄荷生活洗衣凝珠",
        variety:"生活",
        price:39,
        count:0,
        discount:0.6
      }
    ],
    word_list:[
      {
        id:0,
        word:"layman",
        phonetiic:"['leimen]",
        means:"n.俗人；外行",
        example:"That player is a layman; he plays football with his hands",
        example_c:"那个运动员是个外行，他用他的手碰足球",
        im:"../../图片/单词1-例子.jpg",
        image1:"../../图片/单词1-1.jpg",
        image2:"../../图片/单词1-2.jpg",
        image3:"../../图片/单词1-3.jpg",
        image4:"../../图片/单词1-4.jpg",
        near_word:"amateur",
        means_E:"a person who does not have expert knowledge of a particular subject"
     },
     {
        id:1,
        word:"study",
        phonetiic:"[ˈstʌdi]",
        means:"v.学习；研究 ,n.学习；书房",
        example:"I have to study for my exam.",
        example_c:"我不得不为了我的考试而学习",
        im:"../../图片/单词2-例子.jpg",
        image1:"../../图片/单词2-1.jpg",
        image2:"../../图片/单词2-2.jpg",
        image3:"../../图片/单词2-3.jpg",
        image4:"../../图片/单词2-4.jpg",
        near_word:"learn,consider",
        means_E:"to spend time learning about a subject by reading, going to college, etc"
     },
     {
      id:2,
      word:"stone",
      phonetiic:"[stoʊn]",
      means:"n.石头；石料；英石",
      example:"These round stones come from a river",
      example_c:"这附近的石头来自于一条小河",
      im:"../../图片/单词3-例子.jpg",
      image1:"../../图片/单词3-1.jpg",
      image2:"../../图片/单词3-2.jpg",
      image3:"../../图片/单词3-3.jpg",
      image4:"../../图片/单词3-4.jpg",
      near_word:"boulder,cobble,pebble",
      means_E:"a hard substance that comes from the ground and is used for building, caving,etc."
   }
    ],
    page:0,
    page1:0,
    page2:0,
    coll_list:[] ,//收藏数组
    coll_index:0,
    name:"斩小百"
  },
  add(id,str){
    let {shop_list}=this.globalData
    for(var item of shop_list){
      if(item.id==id){
        if(str=="+"){
          item.count++
        }else if(str=="-"){
          item.count--
        }
        else{
          item.count++
        }
      }
    }
    wx.setStorageSync("shop_list",this.globalData.shop_list)
  },
  del(id){
    console.log(id)
    let {shop_list}=this.globalData
    for(var item of shop_list){
      if(item.id==id){
        item.count=0
      }
    }
    wx.setStorageSync("shop_list",this.globalData.shop_list)
  }
  
})